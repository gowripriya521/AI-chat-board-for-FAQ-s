# FAQ Chatbot Using Rasa

## Requirements
- Python 3.8+
- Rasa (`pip install rasa`)

## Running the Bot

```bash
rasa train
rasa run
rasa shell
```

## To Use Custom Actions
```bash
rasa run actions
```
